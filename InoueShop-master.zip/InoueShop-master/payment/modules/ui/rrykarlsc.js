function toggleDetail(btn, id) {
  const detail = document.getElementById(id + '-detail');
  const isVisible = detail.style.display === 'block';

  document.querySelectorAll('.method-detail').forEach(el => el.style.display = 'none');
  document.querySelectorAll('.method-toggle').forEach(el => el.classList.remove('clicked'));

  if (!isVisible) {
    detail.style.display = 'block';
    btn.classList.add('clicked');
  }
}

function copyToClipboard(text, button) {
  navigator.clipboard.writeText(text).then(() => {
    const original = button.textContent;
    button.textContent = "Disalin!";
    setTimeout(() => button.textContent = original, 2000);
  });
}