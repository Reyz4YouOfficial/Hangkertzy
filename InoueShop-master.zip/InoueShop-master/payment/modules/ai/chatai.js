  const toggleBtn = document.getElementById("btn-toggle");
    const extraButtons = document.getElementById("extraButtons");

    let isOpen = false;

    function toggleButtons() {
      console.log("Toggle button clicked");

      if (isOpen) {
        console.log("isOpen (before):", isOpen);
        extraButtons.classList.remove("show");
        extraButtons.classList.add("hide");

        setTimeout(() => {
          extraButtons.style.visibility = "hidden";
        }, 400); 
        console.log("Menutup extraButtons");
      } else {
        console.log("isOpen (before):", isOpen);
        extraButtons.style.visibility = "visible";
        extraButtons.classList.remove("hide");
        extraButtons.classList.add("show");

        console.log("Membuka extraButtons");
      }

      isOpen = !isOpen;
      console.log("isOpen (after):", isOpen);
    }

    document.addEventListener("DOMContentLoaded", () => {
      extraButtons.classList.add("hide");
      extraButtons.style.visibility = "hidden";
    });
    


// Owner Contact
function closeOwnerContact() {
  const ownerContactBox = document.getElementById('ownerContactBox');
  if (ownerContactBox) ownerContactBox.style.display = 'none';
}

function openContact() {
  const ownerContactBox = document.getElementById('ownerContactBox');
 
  const isVisible = ownerContactBox.style.display === 'block';

  closeChat();

  if (!isVisible) {
    ownerContactBox.style.display = 'block';
  } else {
    ownerContactBox.style.display = 'none';
  }
}

// Chat
function openChat() {
  const chatContainer = document.getElementById('chatContainer');
  const sendImage = document.getElementById('sendImage');
  
  

  closeOwnerContact();

  if (chatContainer) chatContainer.style.display = 'flex';

  if (sendImage) {
    sendImage.style.visibility = 'visible';
    console.log('sendImage visibility diubah menjadi visible');
  } else {
    console.log('Elemen sendImage tidak ditemukan');
  }
}

function closeChat() {
  const chatContainer = document.getElementById('chatContainer');
  if (chatContainer) chatContainer.style.display = 'none';
}


// Referensi elemen 
const chatBox = document.getElementById('chatBox');
const messageForm = document.getElementById('messageForm');
const messageInput = document.getElementById('messageInput');
const chatContainer = document.getElementById('chatContainer');

let systemPrompt = '';

function updateSystemPrompt() {
  fetch('logic/logic.json')
    .then(response => response.json())
    .then(data => {
      const newSystemPrompt = data.systemPrompt;
      const savedPrompt = localStorage.getItem('systemPrompt');

      if (savedPrompt !== newSystemPrompt) {
        localStorage.setItem('systemPrompt', newSystemPrompt);
      }

      systemPrompt = newSystemPrompt;
    })
    .catch(error => console.error('Gagal memuat logic.json:', error));
}

updateSystemPrompt();

function appendMessage(text, sender) {
  const msg = document.createElement('div');
  msg.className = `message ${sender}`;

  if (sender === 'user') {
    msg.textContent = text;
    chatBox.appendChild(msg);
  } else {
    const linkedText = linkifyHtml(text, {
      defaultProtocol: 'https',
      attributes: {
        target: "_blank",
        style: "color: #00dfff;"
      }
    });
    chatBox.appendChild(msg);
    typeText(linkedText, msg);
  }

  chatBox.scrollTop = chatBox.scrollHeight;
}

function showTyping() {
  const typing = document.createElement('div');
  typing.className = 'message ai typing-indicator';
  typing.id = 'typing';
  typing.innerHTML = '<span class="dot">.</span><span class="dot">.</span><span class="dot">.</span>';
  chatBox.appendChild(typing);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function removeTyping() {
  const typing = document.getElementById('typing');
  if (typing) typing.remove();
}

function typeText(text, element, delay = 30) {
  element.innerHTML = '';
  const temp = document.createElement('div');
  temp.innerHTML = text;

  const nodes = Array.from(temp.childNodes);
  let i = 0;

  function typeNode() {
    if (i >= nodes.length) return;

    const node = nodes[i];

    if (node.nodeType === Node.TEXT_NODE) {
      let j = 0;
      const textContent = node.textContent;

      const typeChar = setInterval(() => {
        if (j < textContent.length) {
          element.innerHTML += textContent[j++];
          chatBox.scrollTop = chatBox.scrollHeight;
        } else {
          clearInterval(typeChar);
          i++;
          typeNode();
        }
      }, delay);
    } else if (node.nodeType === Node.ELEMENT_NODE) {
      const wrapper = node.cloneNode(false);
      element.appendChild(wrapper);

      const childText = node.textContent;
      let j = 0;

      const typeChar = setInterval(() => {
        if (j < childText.length) {
          wrapper.innerHTML += childText[j++];
          chatBox.scrollTop = chatBox.scrollHeight;
        } else {
          clearInterval(typeChar);
          i++;
          typeNode();
        }
      }, delay);
    }
  }

  typeNode();
}

function fetchWithTimeout(url, options = {}, timeout = 8000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("Timeout")), timeout);
    fetch(url, options).then(response => {
      clearTimeout(timer);
      resolve(response);
    }).catch(err => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

messageForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const userMessage = messageInput.value.trim();
  if (!userMessage) return;

  appendMessage(userMessage, 'user');
  messageInput.value = '';
  showTyping();

  const fullMessage = `${systemPrompt}\nUser: ${userMessage}`;
  let modelDipakai = "Tidak ada";

  const aiReply = await (async () => {
    const sources = [
      {
        name: "LLaMA 3 70B Versatile - Apizell",
        url: `https://apizell.web.id/ai/llama3370bversatile?text=${encodeURIComponent(fullMessage)}`,
        parser: res => res.result
      },
      {
        name: "LLaMA 3 70B - Apizell",
        url: `https://apizell.web.id/ai/llama3370b?text=${encodeURIComponent(fullMessage)}`,
        parser: res => res.result
      },
      {
        name: "LLaMA 33 70B - Siputz",
        url: `https://api.siputzx.my.id/api/ai/meta-llama-33-70B-instruct-turbo?content=${encodeURIComponent(fullMessage)}`,
        parser: res => res.data,
        valid: res => res.status
      },
      {
        name: "LLaMA 33 - Siputz",
        url: `https://api.siputzx.my.id/api/ai/llama33?prompt=Be%20a%20helpful%20assistant&text=${encodeURIComponent(fullMessage)}`,
        parser: res => res.data,
        valid: res => res.status
      },
      {
        name: "Blackbox AI - Siputz",
        url: `https://api.siputzx.my.id/api/ai/blackboxai-pro?content=${encodeURIComponent(fullMessage)}`,
        parser: res => res.data,
        valid: res => res.status
      },
      {
        name: "LLaMA 3 8B - Apizell",
        url: `https://apizell.web.id/ai/llama38b8192?text=${encodeURIComponent(fullMessage)}`,
        parser: res => res.result
      }
    ];

    for (const source of sources) {
      try {
        console.log("Mencoba:", source.name);
        const res = await fetchWithTimeout(source.url, {}, 5000); 
        const json = await res.json();
        const isValid = source.valid ? source.valid(json) : !!source.parser(json);
        const parsed = source.parser(json)?.trim();

        if (isValid && parsed) {
          modelDipakai = source.name;
          return parsed;
        }
        console.warn(source.name, "tidak valid atau kosong.");
      } catch (err) {
        console.warn(source.name, "gagal:", err.message);
      }
    }

    modelDipakai = "Semua gagal";
    return "Semua model gagal merespons.";
  })();

  console.log("AI Raw Reply:", aiReply);

  let finalReply = aiReply.replace(/<think>[\s\S]*?<\/think>/gi, '').trim();
  finalReply = finalReply.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');

  console.log("Model dipakai:", modelDipakai);
  removeTyping();
  appendMessage(finalReply, 'ai');
});

function adjustChatPosition() {
  chatContainer.style.top = window.innerHeight < 500 ? '30%' : '50%';
}

window.addEventListener('resize', adjustChatPosition);