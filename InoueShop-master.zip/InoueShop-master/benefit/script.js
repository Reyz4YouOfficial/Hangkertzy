document.querySelectorAll('.neon-button').forEach(button => {
      button.addEventListener('click', () => {
        const targetId = button.getAttribute('data-target');
        document.querySelectorAll('.panel-content').forEach(panel => {
          if (panel.id === targetId) {
            panel.classList.toggle('show');
          } else {
            panel.classList.remove('show');
          }
        });
      });
    });

    document.querySelectorAll('.panel-content').forEach(panel => {
      const warning = panel.querySelector('.scroll-warning');
      let lastScrollTop = 0;

      panel.addEventListener('scroll', () => {
        const scrollTop = panel.scrollTop;
        if (scrollTop > lastScrollTop) {
          warning.classList.add('hidden');
        } else {
          warning.classList.remove('hidden');
        }
        lastScrollTop = scrollTop <= 0 ? 0 : scrollTop;
      });
    });
    
    function toggleFAQ(element) {
      const answer = element.nextElementSibling;
      const arrow = element.querySelector('.arrow');
      const isVisible = answer.style.display === 'block';

      answer.style.display = isVisible ? 'none' : 'block';
      arrow.classList.toggle('rotate', !isVisible);
    }